# Etapa 2 — arquitectura recomendada para Strangely

Esta lista es el trabajo que falta para pasar de la demostración a una versión que conecte usuarios reales.

## Componentes
1. **Supabase Realtime**: señalización para negociar llamadas y eventos de chat.
2. **Emparejamiento**: una cola administrada en el servidor para evitar que dos personas sean asignadas a distintas salas simultáneamente.
3. **Canal de conversación**: canal único por pareja, con autorización y expiración.
4. **WebRTC**: `RTCPeerConnection`, intercambio de ofertas/respuestas y candidatos ICE.
5. **TURN**: servicio de retransmisión para redes donde no se logra conexión directa.
6. **Moderación**: reportes, bloqueo, límites anti-spam, desconexión rápida y procedimiento para responder a abusos.

## Orden de implementación
- Crear proyecto Supabase y comprobar Realtime en dos navegadores.
- Implementar cola de espera segura en una función del servidor o una operación SQL transaccional.
- Añadir chat de texto y botón “Siguiente”.
- Añadir señalización WebRTC y controles de cámara/micrófono.
- Probar con dos dispositivos y redes distintas.
- Revisar seguridad y privacidad antes de publicarlo como servicio real.

No es suficiente con usar un canal público compartido para emparejar a todos los usuarios: eso puede exponer mensajes o crear emparejamientos conflictivos. La asignación de salas y los permisos deben diseñarse antes de habilitar conexiones públicas.
