const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
let mode = "text";
let lang = "es";
let cameraStream = null;
let micMuted = false;
let cameraEnabled = true;

const copy = {
  es: {
    safetyNav:"Seguridad", eyebrow:"Una conversación puede cambiar tu día", headline:'El mundo está<br><span class="gradient-text">a una charla de distancia.</span>',
    subhead:"Conoce personas nuevas de cualquier parte del mundo. Sin perfiles complicados, solo conversaciones.",
    chooseMode:"ELIGE CÓMO CONECTAR", textChat:"Chat de texto", textDesc:"Habla escribiendo", videoChat:"Videollamada", videoDesc:"Habla cara a cara",
    adultConfirm:"Confirmo que tengo 18 años o más y acepto las normas de la comunidad.", start:"Encontrar a alguien",
    demoNote:"Prototipo de demostración: todavía no conecta con personas reales.", trust1:"Conversaciones espontáneas",trust2:"Conexiones internacionales",trust3:"Tú decides cuándo salir",
    demoPill:"MODO DEMO",waitingPerson:"La otra persona aparecerá aquí",you:"Tú",videoDemoDisclaimer:"La cámara local puede probarse; no hay otra persona conectada en esta versión.",
    demoConversation:"Vista previa de conversación — los mensajes no se envían a nadie.",stranger:"Persona desconocida",sampleHello:"¡Hola! ¿Desde qué parte del mundo te conectas?",
    sampleReply:"¡Hola! Me gusta conocer gente nueva.",messagePlaceholder:"Escribe un mensaje...",report:"⚑ Reportar",demoOnly:"Solo vista previa local",nextPerson:"Siguiente persona",
    safetyTitle:"Conecta con curiosidad. Cuídate siempre.",safetyCopy:"No compartas datos personales, ubicación exacta, contraseñas ni información financiera. Bloquea y reporta conductas que te incomoden.",
    footer:"Un proyecto independiente en desarrollo · 2026",rules:"Normas",privacy:"Privacidad",textTitle:"Chat de texto",videoTitle:"Videollamada",
    needAdult:"Para continuar, confirma que tienes 18 años o más.",cameraDenied:"No se pudo acceder a la cámara. Revisa los permisos del navegador.",
    cameraOn:"Cámara activada solo en tu dispositivo.",cameraOff:"Cámara apagada.",micOn:"Micrófono activo en tu dispositivo.",micOff:"Micrófono silenciado.",
    reportDemo:"En la versión de prueba, los reportes no se envían a un equipo de moderación.",nextDemo:"No hay usuarios reales todavía. El emparejamiento se conectará en la siguiente etapa.",
    rulesInfo:"Normas por preparar: prohibido el acoso, las amenazas, el spam y compartir contenido íntimo sin consentimiento.",privacyInfo:"Aviso provisional: este prototipo no crea cuentas ni envía mensajes a un servidor. No lo publiques como servicio real sin una política de privacidad revisada.",
    messageEmpty:"Escribe un mensaje primero."
  },
  en: {
    safetyNav:"Safety", eyebrow:"One conversation can change your day", headline:'The world is<br><span class="gradient-text">just one chat away.</span>',
    subhead:"Meet new people from anywhere in the world. No complicated profiles, just conversations.",
    chooseMode:"CHOOSE HOW TO CONNECT", textChat:"Text chat", textDesc:"Talk by typing", videoChat:"Video chat", videoDesc:"Talk face to face",
    adultConfirm:"I confirm I am 18 or older and agree to the community rules.", start:"Find someone",
    demoNote:"Demo prototype: it does not connect to real people yet.", trust1:"Spontaneous conversations",trust2:"International connections",trust3:"You choose when to leave",
    demoPill:"DEMO MODE",waitingPerson:"The other person will appear here",you:"You",videoDemoDisclaimer:"You can test your local camera; no other person is connected in this version.",
    demoConversation:"Conversation preview — messages are not sent to anyone.",stranger:"Stranger",sampleHello:"Hi! What part of the world are you connecting from?",
    sampleReply:"Hi! I enjoy meeting new people.",messagePlaceholder:"Write a message...",report:"⚑ Report",demoOnly:"Local preview only",nextPerson:"Next person",
    safetyTitle:"Connect with curiosity. Stay safe.",safetyCopy:"Do not share personal details, exact location, passwords, or financial information. Block and report behavior that makes you uncomfortable.",
    footer:"Independent project in development · 2026",rules:"Rules",privacy:"Privacy",textTitle:"Text chat",videoTitle:"Video chat",
    needAdult:"Please confirm that you are 18 or older to continue.",cameraDenied:"Could not access the camera. Check your browser permissions.",
    cameraOn:"Camera enabled on your device only.",cameraOff:"Camera off.",micOn:"Microphone active on your device.",micOff:"Microphone muted.",
    reportDemo:"In this demo, reports are not sent to a moderation team.",nextDemo:"There are no real users yet. Matching will be connected in the next stage.",
    rulesInfo:"Rules to be finalized: harassment, threats, spam, and sharing intimate content without consent are prohibited.",privacyInfo:"Temporary notice: this prototype creates no accounts and sends no messages to a server. Do not publish it as a real service without a reviewed privacy policy.",
    messageEmpty:"Write a message first."
  }
};
function t(key){return copy[lang][key] || copy.es[key] || key}
function setLanguage(next) {
  lang = next;
  document.documentElement.lang = lang;
  $$("[data-i18n]").forEach(el => { const key=el.dataset.i18n; if(copy[lang][key]) el.innerHTML=copy[lang][key]; });
  $$("[data-i18n-placeholder]").forEach(el => {el.placeholder=t(el.dataset.i18nPlaceholder)});
  $("#languageBtn").textContent = lang === "es" ? "EN" : "ES";
  $("#chatTitle").textContent = mode === "text" ? t("textTitle") : t("videoTitle");
}
$("#languageBtn").addEventListener("click", () => setLanguage(lang === "es" ? "en" : "es"));
$$(".mode-option").forEach(btn => btn.addEventListener("click", () => {
  mode = btn.dataset.mode;
  $$(".mode-option").forEach(b => b.classList.toggle("selected", b === btn));
}));
function toast(msg) {
  const el=$("#toast"); el.textContent=msg; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>el.classList.remove("show"),3400);
}
function showChat() {
  if(!$("#adultCheck").checked){toast(t("needAdult"));return}
  $("#homeView").classList.add("hidden"); $("#chatView").classList.remove("hidden");
  $("#chatTitle").textContent = mode === "text" ? t("textTitle") : t("videoTitle");
  $("#videoStage").classList.toggle("hidden", mode !== "video");
  $("#messages").classList.toggle("hidden", mode === "video");
  $("#messageForm").classList.toggle("hidden", mode === "video");
  $("#statusText").textContent = t("demoOnly");
  if(mode === "video") startCamera();
  window.scrollTo({top:0,behavior:"smooth"});
}
async function startCamera() {
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({video:true,audio:true});
    $("#localVideo").srcObject = cameraStream;
    cameraEnabled = true; micMuted=false;
    toast(t("cameraOn"));
  } catch(e) { toast(t("cameraDenied")); }
}
function stopCamera() {
  if(cameraStream) cameraStream.getTracks().forEach(track=>track.stop());
  cameraStream=null; $("#localVideo").srcObject=null;
}
$("#startBtn").addEventListener("click", showChat);
$("#backBtn").addEventListener("click", () => {stopCamera();$("#chatView").classList.add("hidden");$("#homeView").classList.remove("hidden");});
$("#nextBtn").addEventListener("click", () => { toast(t("nextDemo")); });
$("#reportBtn").addEventListener("click", () => { toast(t("reportDemo")); });
$("#cameraBtn").addEventListener("click", () => {
  if(!cameraStream){startCamera();return}
  cameraEnabled=!cameraEnabled; cameraStream.getVideoTracks().forEach(track=>track.enabled=cameraEnabled);
  toast(cameraEnabled?t("cameraOn"):t("cameraOff"));
});
$("#micBtn").addEventListener("click", () => {
  if(!cameraStream){toast(t("cameraDenied"));return}
  micMuted=!micMuted; cameraStream.getAudioTracks().forEach(track=>track.enabled=!micMuted);
  toast(micMuted?t("micOff"):t("micOn"));
});
$("#stopVideoBtn").addEventListener("click", () => {stopCamera();toast(t("cameraOff"));});
$("#messageForm").addEventListener("submit", e => {
  e.preventDefault(); const input=$("#messageInput"); const value=input.value.trim();
  if(!value){toast(t("messageEmpty"));return}
  const bubble=document.createElement("div");bubble.className="message sent";
  const name=document.createElement("span");name.className="message-name";name.textContent=t("you");
  const p=document.createElement("p");p.textContent=value;
  const time=document.createElement("time");time.textContent=new Date().toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
  bubble.append(name,p,time);$("#messages").appendChild(bubble);$("#messages").scrollTop=$("#messages").scrollHeight;input.value="";
  toast(t("nextDemo"));
});
$("#rulesLink").addEventListener("click",e=>{e.preventDefault();toast(t("rulesInfo"))});
$("#privacyLink").addEventListener("click",e=>{e.preventDefault();toast(t("privacyInfo"))});
