# Strangely — prototipo inicial

Página bilingüe (español/inglés) con diseño claro y minimalista. No usa framework y no necesita instalación.

## Qué funciona en este prototipo

- Diseño adaptable a móvil y computadora.
- Cambio de idioma español/inglés.
- Selector entre chat de texto y videollamada.
- Pantalla de conversación y controles de demostración.
- En modo video, puede solicitar acceso a la cámara y al micrófono locales.
- Botones de demostración para reportar y pasar a la siguiente persona.

## Qué NO funciona todavía

**Este prototipo no conecta a desconocidos reales.** Los mensajes que escribes se quedan en tu navegador; el mensaje de demostración no se transmite a nadie. El botón de siguiente persona y el de reportar son demostrativos. La cámara local no es una videollamada.

No lo presentes como un servicio de chat ya operativo ni lo abras al público como producto real todavía.

## Probar en Windows

1. Descarga y descomprime `strangely-prototipo.zip`.
2. Abre la carpeta `strangely-web`.
3. Haz doble clic en `index.html` para probar la vista y el chat simulado.
4. Para probar cámara/micrófono de forma más fiable, abre la carpeta en un servidor local. Una opción sencilla es instalar Visual Studio Code y la extensión Live Server, luego pulsa **Go Live**.
5. Marca la casilla de mayoría de edad y pulsa **Encontrar a alguien**. Cambia entre chat y video. Para la cámara, concede permiso al navegador.

## Publicar gratis con Cloudflare Pages

1. Crea una cuenta en Cloudflare y una cuenta en GitHub si aún no tienes.
2. Crea un repositorio nuevo en GitHub y sube los archivos de esta carpeta (`index.html`, `styles.css`, `app.js` y este README).
3. En Cloudflare abre **Workers & Pages** → **Create application** → **Pages** → **Import an existing Git repository**.
4. Elige el repositorio. Para una página estática sin compilación, configura el comando de build como `exit 0` y el directorio de salida como `/` (o la carpeta raíz del proyecto, según el formulario).
5. Publica y prueba la dirección `*.pages.dev` que te asignen.

Guía oficial: https://developers.cloudflare.com/pages/framework-guides/deploy-anything/

## Etapa siguiente: conexiones reales

La siguiente etapa requiere configurar un backend. Una ruta económica para un MVP es Supabase Realtime para señalización y mensajes, y WebRTC para audio/video. Antes de abrirlo al público habrá que implementar emparejamiento fiable, límites de uso, controles de acceso, reportes/moderación, política de privacidad y reglas de comunidad.

Documentación:
- Supabase Realtime: https://supabase.com/docs/guides/realtime
- Supabase Broadcast: https://supabase.com/docs/guides/realtime/broadcast
- WebRTC: https://webrtc.org/

### Nota de seguridad para la etapa real

- En el navegador solo se puede usar la clave publicable/anon de Supabase; nunca incluyas la `service_role` key en el frontend.
- No recolectes ni guardes audio/video sin una razón clara y consentimiento.
- WebRTC puede requerir un servidor TURN para usuarios detrás de ciertas redes. STUN por sí solo no garantiza que todas las conexiones funcionen.
- No uses anuncios invasivos en una experiencia de video/chat. Revisa las políticas de la red publicitaria antes de monetizar.
- Si permites adultos, aplica controles de edad y un proceso de respuesta a reportes antes del lanzamiento.
